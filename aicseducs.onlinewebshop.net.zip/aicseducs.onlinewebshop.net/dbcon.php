<?php
ob_start();

include('db.php');




	

if (isset($_POST['mlogin'])) {
    $username = mysqli_real_escape_string($con, $_POST['m_username']);
    $password = mysqli_real_escape_string($con, $_POST['pass']);

    $query = "SELECT * FROM m_login WHERE username='$username' AND password='$password'";
    $result = mysqli_query($con, $query);

    if (mysqli_num_rows($result) > 0) {
        $user = mysqli_fetch_assoc($result);
        $_SESSION['m_username'] = $user['username']; // Set session variable for username
        header('Location: Teacher.php'); // Redirect to the dashboard on successful login
        exit();
    } else {
        $_SESSION['status'] = "Invalid username or password!";
        header('Location: 404.html'); // Redirect to error page
        exit();
    }
}

    if (isset($_POST['login'])) {
        $id_student = mysqli_real_escape_string($con, $_POST['id_student']);
        $pass = mysqli_real_escape_string($con, $_POST['pass']);

        $query = "SELECT * FROM slogin WHERE id_student='$id_student' AND pass='$pass'";
        $result = mysqli_query($con, $query);

        if (mysqli_num_rows($result) > 0) {
            $user = mysqli_fetch_assoc($result);
            $_SESSION['id_student'] = $user['id_student']; // Set session variable for student ID
            $_SESSION['section'] = $user['Section']; // Store section in session
            header('Location: test.php'); // Redirect to the dashboard on successful login
            exit();
        } else {
            $_SESSION['status'] = "Invalid ID or password!";
            header('Location: 404.html'); // Redirect back to login page with error message
            exit();
        }
    }

$selectedBranch = isset($_GET['branch']) ? $_GET['branch'] : '';
$branchesCourses = [
    'Commonwealth College' => ['BS Computer Science', 'BS Engineering', 'BS Entreprenourship'],
    'CommonwealthSHS' => ['Information Communication Technology - ict', 'Accountancy, Business and Management (ABM)', 'General Academic Strand (GAS)'],
   
    // Add more branches and corresponding courses here
];


$branchesCoursesSection = [
    'CommonwealthSHS' => ['ICT-1', 'ABM-13', 'GAS-12'], 
    'Commonwealth College' => ['BS2AA', 'BS2EA', 'CE112'], 
    
];

if (isset($_POST['save_changes'])) {
    $id_student = mysqli_real_escape_string($con, $_POST['id_student']);
    $pass = mysqli_real_escape_string($con, $_POST['pass']);
    $Cpass = mysqli_real_escape_string($con, $_POST['Cpass']);
    $Fname = mysqli_real_escape_string($con, $_POST['Fname']);
    $Mname = mysqli_real_escape_string($con, $_POST['Mname']);
    $Lname = mysqli_real_escape_string($con, $_POST['Lname']);
    $Suffix = mysqli_real_escape_string($con, $_POST['Suffix']);
    $Branch = mysqli_real_escape_string($con, $_POST['Branch']);
    $Course = mysqli_real_escape_string($con, $_POST['Course']);
    $Section = mysqli_real_escape_string($con, $_POST['Section']);

    if ($pass != $Cpass) {
        $_SESSION['status'] = "Passwords do not match!";
        header('Location: test.php');
        exit();
    }

    $check_query = "SELECT * FROM slogin WHERE id_student='$id_student'";
    $check_result = mysqli_query($con, $check_query);
    if (mysqli_num_rows($check_result) > 0) {
        $_SESSION['status'] = "Student ID already exists!";
        header('Location: registration.php');
        exit();
    }

    $query = "INSERT INTO slogin (id_student, pass, Cpass, Fname, Mname, Lname, Suffix, Branch, Course, Section) VALUES ('$id_student', '$pass', '$Cpass', '$Fname', '$Mname', '$Lname', '$Suffix', '$Branch', '$Course', '$Section')";

    if (mysqli_query($con, $query)) {
        
        $_SESSION['section'] = $Section; // Store section in session
        header('Location: Slogin.php');
        exit();
    } else {
        echo "Error: " . mysqli_error($con);
        $_SESSION['status'] = "Something went wrong!";
        header('Location: registration.php');
        exit();
    }
}

if (isset($_POST['save_evaluation'])) {
    $user_id = mysqli_real_escape_string($con, $_POST['user_id']); // Retrieve hidden input value
    $teacher_id = mysqli_real_escape_string($con, $_POST['teacher_id']);
    $Tname = mysqli_real_escape_string($con, $_POST['Tname']);
    $Tsubject = mysqli_real_escape_string($con, $_POST['Tsubject']);
    $Q1 = mysqli_real_escape_string($con, $_POST['Q1']);
    $Q2 = mysqli_real_escape_string($con, $_POST['Q2']);
    $Q3 = mysqli_real_escape_string($con, $_POST['Q3']);
    $Q4 = mysqli_real_escape_string($con, $_POST['Q4']);
    $Q5 = mysqli_real_escape_string($con, $_POST['Q5']);
    $Q6 = mysqli_real_escape_string($con, $_POST['Q6']);
    $Q7 = mysqli_real_escape_string($con, $_POST['Q7']);
    $Q8 = mysqli_real_escape_string($con, $_POST['Q8']);
    $Q9 = mysqli_real_escape_string($con, $_POST['Q9']);

    $query = "INSERT INTO evaluation_form (user_id, teacher_id, Tname, Tsubject, Q1, Q2, Q3, Q4, Q5, Q6, Q7, Q8, Q9) 
              VALUES ('$user_id', '$teacher_id', '$Tname', '$Tsubject', '$Q1', '$Q2', '$Q3', '$Q4', '$Q5', '$Q6', '$Q7', '$Q8', '$Q9')";

    if (mysqli_query($con, $query)) {
        header('Location: test.php');
        exit();
    } else {
        $_SESSION['status'] = "Something went wrong while saving the evaluation!";
        header('Location: evaluation.php');
        exit();
    }
}


error_reporting(0);

$msg = "";

// If upload button is clicked ...
if (isset($_POST['save_teacher'])) {
    $Tname = mysqli_real_escape_string($con, $_POST['Tname']);
    $Tsubject = mysqli_real_escape_string($con, $_POST['Tsubject']);
    $Branch = mysqli_real_escape_string($con, $_POST['Branch']);
    $Section = mysqli_real_escape_string($con, $_POST['Section']);
    $filename = $_FILES["image"]["name"];
    $tempname = $_FILES["image"]["tmp_name"];
    $folder = "./teacher/" . $filename;

    // Check if directory exists, if not create it
    if (!is_dir("./teacher/")) {
        mkdir("./teacher/", 0777, true);
    }

    // Move the uploaded image into the folder: img
    if (move_uploaded_file($tempname, $folder)) {
        // Insert form data and image path into the database
        $sql = "INSERT INTO teacher (Tname, Tsubject, Branch, Section, image_path) VALUES ('$Tname', '$Tsubject', '$Branch', '$Section', '$folder')";
        $query_run = mysqli_query($con, $sql);
        
        if ($query_run) {
            $msg = "Image uploaded and teacher added successfully!";
        } else {
            $msg = "Failed to add teacher!";
        }
    } else {
        $msg = "Failed to upload image!";
    }

    // Optionally, you can redirect to a confirmation page or back to the form
    header('Location: Teacher.php');
    exit();
}



// Handle student info update
if (isset($_POST['edit_changes'])) {
    $student_id = mysqli_real_escape_string($con, $_POST['student_id']);
    $fullname = mysqli_real_escape_string($con, $_POST['fullname']);
    $emails = mysqli_real_escape_string($con, $_POST['emails']);
    $Phonenum = mysqli_real_escape_string($con, $_POST['Phonenum']);
    $Section = mysqli_real_escape_string($con, $_POST['Section']);
    $age = mysqli_real_escape_string($con, $_POST['age']);

    $query = "UPDATE regform SET fullname='$fullname', emails='$emails', Phonenum='$Phonenum', Section='$Section', age='$age' WHERE id=$student_id";

    if (mysqli_query($con, $query)) {
        // Success message modal
        echo "<script>
                $(document).ready(function(){
                    $('#successModal').modal('show');
                });
              </script>";
    } else {
        // Error message modal
        echo "<script>
                $(document).ready(function(){
                    $('#errorModal').modal('show');
                });
              </script>";
    }
}
if (isset($_POST['delete_student'])) {
    $id_student = $_POST['id_student'];
    $query = "DELETE FROM slogin WHERE id_student = '$id_student' ";
    $query_run = mysqli_query($con, $query);

    if ($query_run) {
        echo '<script>alert("Data deleted")</script>';
        header("Location: index.php");
        exit(); 
    } else {
        echo '<script>alert("Data deletion failed")</script>';
        header("Location: Teacher.php");
        exit();
    }
}

if (isset($_POST['delete_question'])) { 
    $id = $_POST['id'];
    $query = "DELETE FROM questions WHERE id = '$id' ";
    $query_run = mysqli_query($con, $query);

    if ($query_run) {
        echo '<script>alert("Data deleted")</script>';
        header("Location: question.php");
        exit(); 
    } else {
        echo '<script>alert("Data deletion failed")</script>';
        header("Location: Teacher.php");
        exit();
    }
}


if (isset($_POST['save_question'])) {
    $id = mysqli_real_escape_string($con, $_POST['id']);
    $question_text = mysqli_real_escape_string($con, $_POST['question_text']);
    $rate = mysqli_real_escape_string($con, $_POST['rate']);

    $query = "INSERT INTO questions (id, question_text, rate) VALUES ('$id', '$question_text', '$rate')";

    if (mysqli_query($con, $query)) {
        header('Location: question.php');
        exit();
    } else {
        $_SESSION['status'] = "Something went wrong while saving the question!";
        header('Location: evaluation.php');
        exit();
    }
}


if (isset($_POST['save_subject'])) {
    $Tsubject = mysqli_real_escape_string($con, $_POST['Tsubject']);
    $query = "INSERT INTO teacher (Tsubject) VALUES ('$Tsubject')";
    if (mysqli_query($con, $query)) {
        header('Location: managesubject.php');
        exit();
    } else {
        $_SESSION['status'] = "Something went wrong while saving the subject!";
        header('Location: managesubject.php');
        exit();
    }
}


if (isset($_POST['update_subject'])) {
    $id = mysqli_real_escape_string($con, $_POST['edit_id']);
    $subject = mysqli_real_escape_string($con, $_POST['edit_subject']);
    
    $query = "UPDATE teacher SET Tsubject='$subject' WHERE id='$id'";
    $query_run = mysqli_query($con, $query);

    if ($query_run) {https://cp1.awardspace.net/#
        $_SESSION['message'] = "Subject updated successfully";
    } else {
        $_SESSION['message'] = "Subject update failed";
    }
    header('Location: managesubject.php');
    exit();
}

if (isset($_POST['delete_subject'])) {
    $id = mysqli_real_escape_string($con, $_POST['delete_id']);
    
    $query = "DELETE FROM teacher WHERE id='$id'";
    $query_run = mysqli_query($con, $query);

    if ($query_run) {
        $_SESSION['message'] = "Subject deleted successfully";
    } else {
        $_SESSION['message'] = "Subject deletion failed";
    }
    header('Location: managesubject.php');
    exit();
}
ob_end_flush();
?>
